package firstpack;

public class BasicMath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(2+2);
		//Parenthesis
		//Exponents 
		//Multiplication
		//Division
		//Addition
		//Subtraction
		//System.out.println(4*(2+8/2));
		
		int var1 = 4;
		int var2 = 5;
		int apple = var1+var2;
		System.out.println(apple);
	}

}
