package firstpack;

public class FirstClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.print("Hello World! ");
		System.out.println("Hello my name is Daniel"); //This line of code prints my name
		
		//This is my first comment
		//System.out.println("Test");
		/*
		 * This 
		 * is
		 * a
		 * multi
		 * line
		 * comment
		 */
	}

}