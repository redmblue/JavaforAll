package firstpack;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("My favorite color is orange");
	}

}
